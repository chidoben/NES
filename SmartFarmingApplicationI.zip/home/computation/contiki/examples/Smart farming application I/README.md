# NES-TU-e
Instructions

Navigate to the examples folder on Contiki

Create a new folder (use smart-farming as the folder name)

Copy smart-farming.c and the Makefile into the folder

Launch Cooja, create a new simulation and add a new sky mote

Select smart-farming.c as the contiki process for the mote
